=== Bricksforge ===
Contributors: Daniele De Rosa
Donate link: www.bricksforge.io
Tags: bricks builder, bricksforge
Requires at least: 4.0
Tested up to: 7.0.1
Stable tag: 3.1.8.9
Requires PHP: 8.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==

www.bricksforge.io

== Installation ==

1. Make sure you're using the Bricks version 1.5.1+
1. Upload the plugin files to the `/wp-content/plugins/` directory, or install the plugin through the WordPress plugins screen directly.
1. Activate the plugin through the 'Plugins' screen in WordPress
1. Now you should see the page “Bricksforge” included to the “Bricks” menu
1. Enjoy ;)

== Changelog ==

To have an overview of the changes and new features, visit our [changelog](https://bricksforge.io/version-changelog/)!
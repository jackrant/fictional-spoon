<?php

namespace Bricksforge;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Security policy for the Email Designer's Twig environment.
 *
 * Mail bodies are compiled as Twig templates after submitted form values have
 * already been substituted into them, which makes submitted text part of the
 * template source. This policy is what keeps that from turning into arbitrary
 * PHP calls on the objects that live in the render context.
 *
 * Properties stay readable on every object - they hold data, not behaviour.
 * Method calls are denied unless the object's class is explicitly listed and
 * the method name has a read-only shape (get*, is*, has*). That keeps the
 * WooCommerce order and order item templates working while setters, save()
 * and delete() stay out of reach.
 */
class EmailDesignerSecurityPolicy implements \Twig\Sandbox\SecurityPolicyInterface
{
    /**
     * Tags a mail template may use.
     *
     * Everything that loads another template (include, embed, extends, use,
     * import, from, source) is left out - the environment runs on an empty
     * ArrayLoader, so they have no legitimate use here. So is "do", whose only
     * purpose is calling something for its side effects.
     *
     * @var string[]
     */
    private $allowed_tags = [
        'apply',
        'autoescape',
        'block',
        'filter',
        'for',
        'if',
        'macro',
        'set',
        'spaceless',
        'verbatim',
        'with',
    ];

    /**
     * Filters a mail template may use. The list covers Twig's own filters plus
     * the ones its optional extensions add; naming a filter that is not
     * registered is harmless.
     *
     * @var string[]
     */
    private $allowed_filters = [
        'abs',
        'batch',
        'capitalize',
        'column',
        'convert_encoding',
        'country_name',
        'currency_name',
        'currency_symbol',
        'data_uri',
        'date',
        'date_modify',
        'default',
        'e',
        'escape',
        'filter',
        'first',
        'format',
        'format_currency',
        'format_date',
        'format_datetime',
        'format_number',
        'format_time',
        'html_to_markdown',
        'join',
        'json_encode',
        'keys',
        'language_name',
        'last',
        'length',
        'locale_name',
        'lower',
        'map',
        'markdown_to_html',
        'merge',
        'nl2br',
        'number_format',
        'raw',
        'reduce',
        'replace',
        'reverse',
        'round',
        'slice',
        'slug',
        'sort',
        'spaceless',
        'split',
        'striptags',
        'timezone_name',
        'title',
        'trim',
        'u',
        'upper',
        'url_encode',
    ];

    /**
     * Functions a mail template may use, on top of the ones the Email Designer
     * registers itself.
     *
     * Left out on purpose: constant, include, source, template_from_string,
     * dump, enum and enum_cases.
     *
     * @var string[]
     */
    private $allowed_functions = [
        'block',
        'country_timezones',
        'cycle',
        'date',
        'html_classes',
        'max',
        'min',
        'parent',
        'random',
        'range',
    ];

    /**
     * Classes whose read-only methods may be called from a template.
     *
     * WP_User, WP_Post and friends are deliberately absent: nothing in a mail
     * template needs to call a method on them.
     *
     * @var string[]
     */
    private $allowed_method_classes = [
        'WC_Abstract_Order',
        'WC_Order',
        'WC_Order_Refund',
        'WC_Order_Item',
        'WC_Product',
        'WC_Customer',
        'WC_DateTime',
        'DateTimeInterface',
    ];

    /**
     * Method name prefixes that read state instead of changing it.
     *
     * @var string[]
     */
    private $allowed_method_prefixes = ['get', 'is', 'has'];

    /**
     * @param string[] $custom_function_names Names registered through the
     *                                        bricksforge/email_designer/custom_functions filter.
     */
    public function __construct($custom_function_names = [])
    {
        if (is_array($custom_function_names)) {
            $this->allowed_functions = array_merge($this->allowed_functions, $custom_function_names);
        }

        /**
         * Filter the tags a mail template may use.
         *
         * @param string[] $allowed_tags
         */
        $this->allowed_tags = $this->to_string_list(
            apply_filters('bricksforge/email_designer/sandbox/allowed_tags', $this->allowed_tags)
        );

        /**
         * Filter the filters a mail template may use.
         *
         * @param string[] $allowed_filters
         */
        $this->allowed_filters = $this->to_string_list(
            apply_filters('bricksforge/email_designer/sandbox/allowed_filters', $this->allowed_filters)
        );

        /**
         * Filter the functions a mail template may use.
         *
         * @param string[] $allowed_functions
         */
        $this->allowed_functions = $this->to_string_list(
            apply_filters('bricksforge/email_designer/sandbox/allowed_functions', $this->allowed_functions)
        );

        /**
         * Filter the classes whose read-only methods a mail template may call.
         *
         * Anything added here can be called with get*, is* and has* methods
         * from template code, and mail bodies contain submitted form values.
         * Only add classes that hold data.
         *
         * @param string[] $allowed_method_classes
         */
        $this->allowed_method_classes = $this->to_string_list(
            apply_filters('bricksforge/email_designer/sandbox/allowed_method_classes', $this->allowed_method_classes)
        );
    }

    /**
     * @param string[] $tags
     * @param string[] $filters
     * @param string[] $functions
     * @return void
     */
    public function checkSecurity($tags, $filters, $functions): void
    {
        foreach ($tags as $tag) {
            if (!in_array($tag, $this->allowed_tags, true)) {
                throw new \Twig\Sandbox\SecurityNotAllowedTagError(
                    sprintf('Tag "%s" is not allowed in email templates.', $tag),
                    $tag
                );
            }
        }

        foreach ($filters as $filter) {
            if (!in_array($filter, $this->allowed_filters, true)) {
                throw new \Twig\Sandbox\SecurityNotAllowedFilterError(
                    sprintf('Filter "%s" is not allowed in email templates.', $filter),
                    $filter
                );
            }
        }

        foreach ($functions as $function) {
            if (!in_array($function, $this->allowed_functions, true)) {
                throw new \Twig\Sandbox\SecurityNotAllowedFunctionError(
                    sprintf('Function "%s" is not allowed in email templates.', $function),
                    $function
                );
            }
        }
    }

    /**
     * @param object $obj
     * @param string $method
     * @return void
     */
    public function checkMethodAllowed($obj, $method): void
    {
        if ($obj instanceof \Twig\Template || $obj instanceof \Twig\Markup) {
            return;
        }

        // Printing an object is what PHP does on its own, and the sandbox routes
        // that through here as well. Denying it would break {{ wc_order.date_created }}
        // and anything else that renders through __toString().
        if (strtolower((string) $method) === '__tostring') {
            return;
        }

        if ($this->is_readonly_method_name($method) && $this->is_allowed_method_class($obj)) {
            return;
        }

        $class = get_class($obj);

        throw new \Twig\Sandbox\SecurityNotAllowedMethodError(
            sprintf('Calling "%s" method on a "%s" object is not allowed in email templates.', $method, $class),
            $class,
            $method
        );
    }

    /**
     * Reading a property returns data, so it stays allowed for every object in
     * the context. Which objects end up there is decided in EmailDesigner,
     * not here.
     *
     * @param object $obj
     * @param string $property
     * @return void
     */
    public function checkPropertyAllowed($obj, $property): void
    {
    }

    /**
     * @param string $method
     * @return bool
     */
    private function is_readonly_method_name($method)
    {
        $method = strtolower((string) $method);

        foreach ($this->allowed_method_prefixes as $prefix) {
            if (strpos($method, $prefix) === 0) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param object $obj
     * @return bool
     */
    private function is_allowed_method_class($obj)
    {
        foreach ($this->allowed_method_classes as $class) {
            if ($obj instanceof $class) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param mixed $value
     * @return string[]
     */
    private function to_string_list($value)
    {
        if (!is_array($value)) {
            return [];
        }

        $list = [];

        foreach ($value as $item) {
            if (is_string($item) && $item !== '') {
                $list[] = $item;
            }
        }

        return array_values(array_unique($list));
    }
}

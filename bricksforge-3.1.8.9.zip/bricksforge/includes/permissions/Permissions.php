<?php

namespace Bricksforge;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Permissions Handler
 */
class Permissions
{

    public function __construct()
    {
        add_filter('bricks/builder/elements', [$this, 'render_elements_by_role']);
        add_action('wp_ajax_create_user_role', [$this, 'create_user_role']);
        add_action('wp_head', [$this, 'hide_tab_area']);
    }

    /**
     * Get a value from data - handles both object and array formats
     */
    private function get_value($data, $key, $default = null)
    {
        if (is_object($data) && isset($data->$key)) {
            return $data->$key;
        } elseif (is_array($data) && isset($data[$key])) {
            return $data[$key];
        }
        return $default;
    }

    /**
     * Render Elements By Role
     */
    public function render_elements_by_role($elements)
    {

        if (!is_user_logged_in() || bricks_is_frontend()) {
            return $elements;
        }

        $user = wp_get_current_user();
        $roles = get_option('brf_permissions_roles');
        $rendered_elements = $elements;
        $hide_only = false;

        if (!isset($roles) || empty($roles) || !is_array($roles)) {
            return $elements;
        }

        $deactivated_elements = [];

        foreach ($roles as $role) {
            $role_value = $this->get_value($role, 'value');
            $permissions = $this->get_value($role, 'permissions');

            if ($role_value && in_array($role_value, $user->roles)) {

                // If permissions->active is not set or false, return $elements
                $permissions_active = $permissions ? $this->get_value($permissions, 'active', false) : false;
                if (!$permissions_active) {
                    return $elements;
                }

                $hide_only_setting = $permissions ? $this->get_value($permissions, 'hideOnly', false) : false;
                if ($hide_only_setting == true) {
                    $hide_only = true;
                }

                // Only add elements to $deactivated_elements if they are not active
                $permission_elements = $permissions ? $this->get_value($permissions, 'elements', []) : [];
                $deactivated_elements = array_filter($permission_elements, function ($e) {
                    $active = $this->get_value($e, 'active', true);
                    return $active === false;
                });

                // Convert $deactivated_elements to an array of element names
                $deactivated_elements = array_map(function ($e) {
                    return $this->get_value($e, 'name');
                }, $deactivated_elements);
            }
        };

        if ($hide_only === true) {
            add_action('wp_head', [$this, 'hide_elements']);
            return $elements;
        }

        // Filter $elements to exclude elements that are in $deactivated_elements
        $rendered_elements = array_filter($elements, function ($elem) use ($deactivated_elements) {
            return !in_array($elem, $deactivated_elements);
        });

        return $rendered_elements ? $rendered_elements : $elements;
    }

    /**
     * Create User Role
     */
    public function create_user_role()
    {

        $role = $_REQUEST['role'];

        $role = json_decode(stripslashes($role));

        if (!isset($role) || !$role) {
            die;
        }

        $cap_array = (array) $role->capabilities;

        add_role($role->value, $role->label, $cap_array);

        echo true;

        die;
    }

    /**
     * Only hide the elements
     */
    public function hide_elements()
    {
        $user = wp_get_current_user();
        $roles = get_option('brf_permissions_roles');
        $rendered_elements = array();

        if (!isset($roles) || empty($roles) || !is_array($roles)) {
            return;
        }

        foreach ($roles as $role) {
            $role_value = $this->get_value($role, 'value');
            $permissions = $this->get_value($role, 'permissions');

            if ($role_value && in_array($role_value, $user->roles)) {
                $permission_elements = $permissions ? $this->get_value($permissions, 'elements', []) : [];
                $active_elements = array_filter($permission_elements, function ($e) {
                    $active = $this->get_value($e, 'active', true);
                    return $active === true;
                });

                $rendered_elements = array_map(function ($element) {
                    return $this->get_value($element, 'name');
                }, $active_elements);
            }
        };

        echo "<style>";
        echo "#bricks-panel-elements-categories .category-layout .sortable-wrapper > li {display: none!important}";
        echo "#bricks-panel-elements-categories .category-basic .sortable-wrapper > li {display: none!important}";
        echo "#bricks-panel-elements-categories .category-general .sortable-wrapper > li {display: none!important}";
        echo "#bricks-panel-elements-categories .category-media .sortable-wrapper > li {display: none!important}";
        echo "#bricks-panel-elements-categories .category-wordpress .sortable-wrapper > li {display: none!important}";
        echo "#bricks-panel-elements-categories .category-single .sortable-wrapper > li {display: none!important}";

        foreach ($rendered_elements as $element) {
            echo "#bricks-panel-elements-categories .category-layout li[data-element-name=" . $element . "] {display: block!important}";
            echo "#bricks-panel-elements-categories .category-basic li[data-element-name=" . $element . "] {display: block!important}";
            echo "#bricks-panel-elements-categories .category-general li[data-element-name=" . $element . "] {display: block!important}";
            echo "#bricks-panel-elements-categories .category-media li[data-element-name=" . $element . "] {display: block!important}";
            echo "#bricks-panel-elements-categories .category-wordpress li[data-element-name=" . $element . "] {display: block!important}";
            echo "#bricks-panel-elements-categories .category-single li[data-element-name=" . $element . "] {display: block!important}";
        }
        echo "</style>";
    }

    /**
     * Hide Tab Area
     */
    public function hide_tab_area()
    {
        if (bricks_is_builder()) {
            $role = $this->get_user_role();

            if (!isset($role) || $role == false) {
                return;
            }

            $permissions = $this->get_value($role, 'permissions');
            if (!$permissions) {
                return;
            }

            if ($this->get_value($permissions, 'hideTabs') === true) {
?>
                <style>
                    #bricks-panel-sticky {
                        display: none;
                    }
                </style>
            <?php
            }
            if ($this->get_value($permissions, 'hideStyleTab') === true) {
            ?>
                <style>
                    #bricks-panel-tabs {
                        display: none;
                    }
                </style>
            <?php
            }
            if ($this->get_value($permissions, 'cleanUpToolbar') === true) {
            ?>
                <style>
                    #bricks-toolbar li:not(.logo, [data-balloon="Edit in WordPress"], .new-tab, .preview, .save, .elements) {
                        display: none;
                    }
                </style>
            <?php
            }
            if ($this->get_value($permissions, 'removeBricksforgePanel') === true) {
            ?>
                <style>
                    #bricks-toolbar li.brf-panel {
                        display: none;
                    }
                </style>
            <?php
            }
            if ($this->get_value($permissions, 'removeBricksforgeTerminal') === true) {
            ?>
                <style>
                    #bricks-toolbar li.brf-terminal {
                        display: none;
                    }
                </style>
            <?php
            }
            if ($this->get_value($permissions, 'hasCustomBuilderColor') === true) {
                $builderColorPrimary = $this->get_value($permissions, 'builderColorPrimary', '');
                $builderColorSecondary = $this->get_value($permissions, 'builderColorSecondary', '');
                $builderColorAccent = $this->get_value($permissions, 'builderColorAccent', '');
                $builderColorText = $this->get_value($permissions, 'builderColorText', '');
            ?>
                <style>
                    :root {
                        --builder-bg: <?php echo $builderColorPrimary ?>;
                        --builder-bg-2: <?php echo $builderColorSecondary ?>;
                        --builder-bg-3: <?php echo $builderColorSecondary ?>;
                        --builder-color-accent: <?php echo $builderColorAccent ?>;
                        --builder-color: <?php echo $builderColorText ?>;
                    }

                    #bricks-toolbar .logo {
                        background-color: <?php echo $builderColorAccent ?>;
                    }

                    [data-control=select] li.hover,
                    [data-control=select] li.selected,
                    [data-control=select] li:hover {
                        color: <?php echo $builderColorText ?>;
                    }

                    [data-control=select] li.hover:after,
                    [data-control=select] li.selected:after,
                    [data-control=select] li:hover:after {
                        background-color: <?php echo $builderColorPrimary ?>;
                    }
                </style>
<?php
            }
        }
    }

    /**
     * Check for user role
     */
    public function get_user_role()
    {
        $user = wp_get_current_user();
        $roles = get_option('brf_permissions_roles');
        $user_role = null;

        if (!isset($roles) || !is_array($roles)) {
            return false;
        }

        if ($roles && count($roles) > 0) {
            foreach ($roles as $role) {
                $role_value = $this->get_value($role, 'value');
                if ($role_value && in_array($role_value, $user->roles)) {
                    $user_role = $role;
                }
            };
        }

        if (isset($user_role)) {
            return $user_role;
        }

        return false;
    }
}

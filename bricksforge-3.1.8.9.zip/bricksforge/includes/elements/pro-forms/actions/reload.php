<?php

namespace Bricksforge\ProForms\Actions;

class Reload
{
    public $name = "reload";
    /**
     * User login
     *
     * @since 1.0
     */
    public function run($form)
    {
        $form_settings = $form->get_settings();
        $delay = isset($form_settings['reloadDelay']) ? $form_settings['reloadDelay'] : 0;

        $form->set_result(
            [
                'action'          => $this->name,
                'type'            => 'reload',
                'delay'           => $delay
            ]
        );
    }
}

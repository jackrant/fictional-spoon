<?php
/**
 * *********************************************************************************
 *    @package    com_joomgallery                                                 **
 *    @author     JoomGallery::ProjectTeam <team@joomgalleryfriends.net>          **
 *    @copyright  2008 - 2026  JoomGallery::ProjectTeam                           **
 *    @license    GNU General Public License version 3 or later                   **
 * *********************************************************************************
 */

namespace Joomgallery\Component\Joomgallery\Administrator\Field;

// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') || die;
// phpcs:enable PSR1.Files.SideEffects

use Joomgallery\Component\Joomgallery\Administrator\Helper\ConfigHelper;
use Joomla\CMS\Event\AbstractEvent;
use Joomla\CMS\Factory;
use Joomla\CMS\Form\Form;

/**
 * List field with dynamic options and useglobal option based on config service
 *
 * @since  4.0.0
 */
class JgdynamiclistField extends JglistField
{
  /**
   * The form field type.
   *
   * @var    string
   * @since  4.0.0
   */
  protected $type = 'jgdynamiclist';

  /**
   * Method to get the field options.
   *
   * @return  object[]  The field option objects.
   *
   * @since   4.0.0
   */
  protected function getOptions()
  {
    $options = [];

    // Get script
    $script = '';

    if(isset($this->element['script']))
    {
      $script = (string) $this->element['script'];
    }
    else
    {
      return $options;
    }

    // Option 1: Plugin listening to onJoomGetOptions
    $event = AbstractEvent::create(
        'onJoomGetOptions',
        [
          'subject' => $this,
          'context' => 'com_joomgallery.config.form',
          'script'  => $script,
        ]
    );
    Factory::getApplication()->getDispatcher()->dispatch($event->getName(), $event);
    $dyn_options = $event->getArgument('result', []);

    // Option 2: Load script from ConfigHelper
    if(method_exists('\Joomgallery\Component\Joomgallery\Administrator\Helper\ConfigHelper', $script))
    {
      $tmp_form    = new Form('com_joomgallery.config');
      $dyn_options = array_merge($dyn_options, ConfigHelper::{$script}($tmp_form, false));
    }

    if(!empty($dyn_options))
    {
      array_push($options, ...$dyn_options);
    }

    reset($options);

    return $options;
  }

  /**
   * Method to get the field options publicly.
   *
   * @return  object[]  The field option objects.
   *
   * @since   4.4.0
   */
  public function dynGetOptions()
  {
    return $this->getOptions();
  }

  /**
   * Method to get the data to be passed to the layout for rendering.
   *
   * @return  array
   *
   * @since 4.4.0
   */
  protected function collectLayoutData(): array
  {
    parent::collectLayoutData();

    // Post process layout data
    $tmp = 1;

    return $this->layoutData;
  }
}

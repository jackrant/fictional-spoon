<?php
/**
 * *********************************************************************************
 *    @package    com_joomgallery                                                 **
 *    @author     JoomGallery::ProjectTeam <team@joomgalleryfriends.net>          **
 *    @copyright  2008 - 2026  JoomGallery::ProjectTeam                           **
 *    @license    GNU General Public License version 3 or later                   **
 * *********************************************************************************
 */

// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') || die;
// phpcs:enable PSR1.Files.SideEffects

define('_JOOM_OPTION',               'com_joomgallery');
define('_JOOM_OPTION_UC',            'COM_JOOMGALLERY');
define('_JOOM_PATH_ADMIN',           JPATH_ADMINISTRATOR.'/components/com_joomgallery');
define('_JOOM_PATH_SITE',            JPATH_SITE.'/components/com_joomgallery');
define('_JOOM_TABLE_IMAGES',         '#__joomgallery');
define('_JOOM_TABLE_CATEGORIES',     '#__joomgallery_categories');
define('_JOOM_TABLE_COLLECTIONS',    '#__joomgallery_collections');
define('_JOOM_TABLE_COLLECTIONS_REF','#__joomgallery_collections_ref');
define('_JOOM_TABLE_COMMENTS',       '#__joomgallery_comments');
define('_JOOM_TABLE_CONFIGS',        '#__joomgallery_configs');
define('_JOOM_TABLE_FAULTIES',       '#__joomgallery_faulties');
define('_JOOM_TABLE_MAINTENANCE',    '#__joomgallery_faulties');
define('_JOOM_TABLE_ORPHANS',        '#__joomgallery_faulties');
define('_JOOM_TABLE_IMG_TYPES',      '#__joomgallery_img_types');
define('_JOOM_TABLE_TYPES',          '#__joomgallery_img_types');
define('_JOOM_TABLE_MIGRATION',      '#__joomgallery_migration');
define('_JOOM_TABLE_TAGS',           '#__joomgallery_tags');
define('_JOOM_TABLE_TAGS_REF',       '#__joomgallery_tags_ref');
define('_JOOM_TABLE_TASKS',          '#__joomgallery_tasks');
define('_JOOM_TABLE_USERS',          '#__joomgallery_users');
define('_JOOM_TABLE_VOTES',          '#__joomgallery_votes');
define('_JOOM_WEBSITE_UPDATES_XML',  'https://www.joomgalleryfriends.net/updates');

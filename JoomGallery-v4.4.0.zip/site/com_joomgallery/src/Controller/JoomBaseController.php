<?php
/**
 * *********************************************************************************
 *    @package    com_joomgallery                                                 **
 *    @author     JoomGallery::ProjectTeam <team@joomgalleryfriends.net>          **
 *    @copyright  2008 - 2026  JoomGallery::ProjectTeam                           **
 *    @license    GNU General Public License version 3 or later                   **
 * *********************************************************************************
 */

namespace Joomgallery\Component\Joomgallery\Site\Controller;

// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') || die;
// phpcs:enable PSR1.Files.SideEffects

use Joomla\CMS\Application\CMSApplication;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\Input\Input;

/**
 * Base controller for standard views
 *
 * @package JoomGallery
 * @since   4.0.0
 */
class JoomBaseController extends BaseController
{
    use RoutingTrait;

    /**
     * Joomgallery\Component\Joomgallery\Administrator\Extension\JoomgalleryComponent
     *
     * @access  protected
     * @var     object
     */
    protected $component;

    /**
     * Joomgallery\Component\Joomgallery\Administrator\Service\Access\Access
     *
     * @access  protected
     * @var     object
     */
    protected $acl;

    /**
     * Constructor.
     *
     * @param   array                $config   An optional associative array of configuration settings.
     *                                         Recognized key values include 'name', 'default_task', 'model_path', and
     *                                         'view_path' (this list is not meant to be comprehensive).
     * @param   MVCFactoryInterface  $factory  The factory.
     * @param   CMSApplication       $app      The Application for the dispatcher
     * @param   Input                $input    The Input object for the request
     *
     * @since   4.0.0
     */
    public function __construct($config = [], ?MVCFactoryInterface $factory = null, ?CMSApplication $app = null, ?Input $input = null)
    {
        parent::__construct($config, $factory, $app, $input);

        // JoomGallery extension class
        $this->component = $this->app->bootComponent(_JOOM_OPTION);

        // Access service class
        $this->component->createAccess();
        $this->acl = $this->component->getAccess();
    }
}
